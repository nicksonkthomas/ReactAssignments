// ---- Sample Product Data ----
const products = [
  { id: 1, name: "IQOO Z11 5G", price: 22999.00, img: "https://fdn2.gsmarena.com/vv/bigpic/vivo-iqoo-z11-5g.jpg", desc: "iQOO Z11 is a 5G Android 16 Smartphone powered by Qualcomm 7s Gen4 with 8 GB RAM and 256 GB storage. It has a 6.83 inches AMOLED display with 144 Hz refresh rate. It features a 50 MP rear camera and a 32 MP front camera. It packs a 9020 mAh Battery with 90W Fast Charging. Notable features include NFC, IP68 Rating, In-Display Fingerprint and USB on-the-go.." },
  { id: 2, name: "Samsung Galaxy M47 5G", price: 24999.00, img: "https://fdn2.gsmarena.com/vv/bigpic/samsung-galaxy-m47-1.jpg", desc: "Samsung Galaxy M47 5G is a 5G Android 16 Smartphone powered by Qualcomm 6 Gen3 with 6 GB RAM and 128 GB storage. It has a 6.7 inches Super AMOLED display with 120 Hz refresh rate. It features a 50 MP + 5 MP + 2 MP Triple rear camera and a 12 MP front camera. It packs a 6000 mAh Battery with 45W Fast Charging. Notable features include IP64 Rating, Expandable Storage, USB on-the-go and Fingerprint Sensor." },
  { id: 3, name: "Oneplus N6", price: 22999.00, img: "https://www.91-img.com/pictures/176471-v3-oneplus-n6-5g-mobile-phone-hres-1.jpg?tr=h-630,q-70", desc: "OnePlus N6 is a 5G Android 16 Smartphone powered by MediaTek 6360 Apex with 4 GB RAM and 128 GB storage. It has a 6.8 inches LCD display with 120 Hz refresh rate. It features a 50 MP Dual rear camera and a 8 MP front camera. It packs a 8000 mAh Battery with 45W Fast Charging. Notable features include NFC, IP65 Rating, Expandable Storage, 3.5mm Headphone Jack and USB on-the-go." },
  { id: 4, name: "Vivo T5X", price: 22499.00, img: "https://fdn2.gsmarena.com/vv/bigpic/vivo-t5x-5g.jpg", desc: "Vivo T5x 5G is a 5G Android 16 Smartphone powered by Mediatek 7400 Turbo with 6 GB RAM and 128 GB storage. It has a 6.76 inches LCD display with 120 Hz refresh rate. It features a 50 MP + 2 MP Dual rear camera and a 32 MP front camera. It packs a 7200 mAh Battery with 44W Fast Charging. Notable features include IP68 & IP69+ Rating, USB on-the-go and Fingerprint Sensor." },
  { id: 5, name: "Oppo Find X9 Ultra", price: 169999.00, img: "https://fdn2.gsmarena.com/vv/bigpic/oppo-find-x9-ultra-new.jpg", desc: "OPPO Find X9 Ultra is a 5G Android 16 Smartphone powered by Qualcomm 8 Elite Gen5 with 12 GB RAM and 512 GB storage. It has a 6.82 inches 2K ProXDR LTPO AMOLED display with 144 Hz refresh rate. It features a 200 MP Penta rear camera and a 50 MP front camera. It packs a 7050 mAh Battery with 100W Fast Charging. Notable features include NFC, IP69 + IP68 + IP66 Rating, Wireless Charging, Reverse Wireless Charging and USB on-the-go." },
  { id: 6, name: "Iphone 17", price: 78999.00, img: "https://fdn2.gsmarena.com/vv/bigpic/apple-iphone-17.jpg", desc: "Apple iPhone 17 is a 5G iOS 26 Smartphone powered by Apple A19 with 8 GB RAM and 256 GB storage. It has a 6.3 inches OLED display with 120 Hz refresh rate. It features a 48 MP + 48 MP Dual rear camera and a 18 MP front camera. It packs a 3692 mAh Battery with Fast Charging. Notable features include NFC, IP68 Rating, Wireless Charging, Reverse Wireless Charging and USB on-the-go.." }
];

const banners = [
    "https://t4.ftcdn.net/jpg/19/66/93/73/240_F_1966937369_W0fBq720PCp6LtTex997mMof5Y917L2A.jpg",
    "https://t4.ftcdn.net/jpg/18/97/02/57/240_F_1897025766_CjncGde14aAxINgW9zmV2orgw5Ru3RV8.jpg",
    "https://t3.ftcdn.net/jpg/19/72/58/12/240_F_1972581222_asakN0guMj7R2X7JVXjtrK2kIf6QDDF6.jpg",
    "https://t3.ftcdn.net/jpg/20/75/58/78/240_F_2075587839_Ul39QY9SPthzvRW2I0Gpi7ohOA7fltCQ.jpg"
];

let current = 0;

function next() {
    current++;

    if (current == banners.length) {
        current = 0;
    }

    document.getElementById("banner").src = banners[current];
}

function previous() {
    current--;

    if (current < 0) {
        current = banners.length - 1;
    }

    document.getElementById("banner").src = banners[current];
}

// ---- Cart helpers (stored in localStorage so it persists across pages) ----
function getCart() {
  return JSON.parse(localStorage.getItem('cart') || '[]');
}

function saveCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
}

function addToCart(id) {
  const p = products.find(x => x.id === id);
  let cart = getCart();
  const existing = cart.find(x => x.id === id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ id: p.id, name: p.name, price: p.price, img: p.img, qty: 1 });
  }
  saveCart(cart);
  updateCartCount();
  alert(p.name + " added to cart!");
}

function removeFromCart(id) {
  let cart = getCart().filter(item => item.id !== id);
  saveCart(cart);
  updateCartCount();
  if (typeof renderCart === 'function') renderCart();
}

function cartTotal() {
  return getCart().reduce((sum, item) => sum + item.price * item.qty, 0);
}

function updateCartCount() {
  const el = document.getElementById('cartCount');
  if (el) {
    const count = getCart().reduce((sum, item) => sum + item.qty, 0);
    el.textContent = count;
  }
}

// Run on every page load
document.addEventListener('DOMContentLoaded', updateCartCount);
