import { MdDelete, MdEdit } from "react-icons/md";
import { useState } from "react";
import "./style.css";

let nextId = 0;

export default function Todos() {
    const [title, setTitle] = useState("");
    const [desc, setDesc] = useState("");
    const [todos, setTodos] = useState([]);
    const [editId, setEditId] = useState(null);

    const handleAdd = () => {
        if (title.trim() === "" || desc.trim() === "") return;

        const avatar = title[0].toUpperCase();

        const newTodo = {
            id: nextId++,
            title,
            desc,
            avatar,
        };

        setTodos([...todos, newTodo]);

        setTitle("");
        setDesc("");
    };

    const handleDelete = (id) => {
        const updatedTodos = todos.filter((todo) => todo.id !== id);
        setTodos(updatedTodos);
    }

    const handleEdit = (todo) => {
        setTitle(todo.title);
        setDesc(todo.desc);
        setEditId(todo.id);
    };


    const handleUpdate = () => {
        if (title.trim() === "" || desc.trim() === "") return;

        const updatedTodos = todos.map((todo) =>
            todo.id === editId
                ? {
                    ...todo,
                    title,
                    desc,
                    avatar: title[0].toUpperCase(),
                }
                : todo
        );

        setTodos(updatedTodos);
        setTitle("");
        setDesc("");
        setEditId(null);
    };

    return (
        <div clasName="main">
            <div className="heading-box">
                <h2 className="heading-one">My Todo List</h2></div>

            <div className="section-one">
                <div className="div-title">
                    <label className="lab-title">Title:</label>

                    <input
                        type="text"
                        className="title"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                    />
                </div>

                <div className="div-desc">
                    <label className="lab-desc">Description:</label>

                    <textarea
                        cols="25"
                        rows="5"
                        className="desc"
                        value={desc}
                        onChange={(e) => setDesc(e.target.value)}
                    ></textarea>
                </div>


                <button
                    className="btn-add"
                    onClick={editId === null ? handleAdd : handleUpdate}
                >
                    {editId === null ? "Add" : "Update"}
                </button>
            </div>

            <div className="list-items">
                {todos.map((todo) => (
                    <div key={todo.id} className="list-item3">

                        <div className="avatar">{todo.avatar}</div>
                        <div>
                            <div className="list-item">{todo.title}</div>
                            <div className="list-item2">{todo.desc}</div>


                        </div>
                        <button
                            className="btn-edit"
                            onClick={() => handleEdit(todo)}
                        >
                            Edit
                        </button>
                        <button className="btn-delete" onClick={() => handleDelete(todo.id)}>
                            <MdDelete />
                        </button>
                    </div>
                ))}

            </div>
        </div>
    );

}